 
 /**
  * @brief a custom datatype that holds a student's information regarding name, id and grades
  * 
  */

typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

// Doxygen comments for the below function definitions have been added in the student.c file
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
