/**
 * @file main.c
 * @author Ahmed Jubaer Ferdous (ferdousa@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-05
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief main function that makes use of all the library functions from student.c and course.c, to demonstrate them using an example.
 * 
 * @return int 
 */

int main()
{
  srand((unsigned) time(NULL));

// course named 'MATH101' created

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

// enrolls 20 students in the MATH101 course

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

// determines the top student for the MATH101 course

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

// prints out how many students are passing and who are they for MATH101 course

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}