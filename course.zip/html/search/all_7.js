var searchData=
[
  ['student_2ec_0',['student.c',['../student_8c.html',1,'']]]
];
