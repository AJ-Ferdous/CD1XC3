/**
 * @file course.h
 * @author Ahmed Jubaer Ferdous (ferdousa@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-05
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief a custom datatype that holds a course information regarding the name, code, students enrolled and total students taking that course. 
 * 
 */
 
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

// Doxygen comments for the below function definitions have been added in the course.c file
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


